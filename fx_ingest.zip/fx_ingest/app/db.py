"""SQLAlchemy engine, session factory and the fx_records table."""
from datetime import datetime

from sqlalchemy import BigInteger, DateTime, String, Text, create_engine, func
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, sessionmaker

from .config import settings

engine = create_engine(settings.database_url, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)


class Base(DeclarativeBase):
    pass


class FxRecordRow(Base):
    __tablename__ = "fx_records"

    id: Mapped[int] = mapped_column(BigInteger, primary_key=True, autoincrement=True)
    # Unique so re-processing the same TAR is idempotent (ON CONFLICT DO NOTHING).
    fx_id: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    fx_details: Mapped[str] = mapped_column(Text)
    created_date: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    # Lineage - which file each row came from, handy for audits / reprocessing.
    source_tar: Mapped[str] = mapped_column(Text)
    source_zip: Mapped[str] = mapped_column(Text)
    ingested_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )


def get_session():
    """FastAPI dependency: one DB session per request."""
    with SessionLocal() as session:
        yield session
