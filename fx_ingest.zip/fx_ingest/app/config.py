"""Runtime settings, read from environment variables (or a .env file)."""
from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_prefix="FX_")

    # PostgreSQL connection (psycopg 3 driver)
    database_url: str = "postgresql+psycopg://fx_user:fx_pass@localhost:5432/fx_db"

    # Root of the shared drive. TAR paths sent to the API must live under here,
    # e.g. a mounted share (/mnt/fx_share) or a UNC path (\\\\server\\fx_share).
    share_root: Path = Path("./sample_share")

    # Safety limits - nested archives can be used as "zip bombs".
    max_zip_bytes: int = 200 * 1024 * 1024    # per ZIP inside the TAR
    max_json_bytes: int = 10 * 1024 * 1024    # per JSON inside a ZIP


settings = Settings()
