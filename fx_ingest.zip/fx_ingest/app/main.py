"""FastAPI entry point.

    uvicorn app.main:app --reload

POST /ingest           {"tar_path": "batch_001.tar"}  -> runs the full pipeline
GET  /records          list stored records
GET  /records/{fx_id}  fetch one record by its hashed reference ID
"""
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import Depends, FastAPI, HTTPException
from sqlalchemy import select
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.orm import Session

from .config import settings
from .db import Base, FxRecordRow, engine, get_session
from .extractor import extract_records
from .schemas import FxRecordOut, IngestRequest, IngestResponse


@asynccontextmanager
async def lifespan(_: FastAPI):
    # Prototype convenience: create the table on startup. Use Alembic for real deployments.
    Base.metadata.create_all(engine)
    yield


app = FastAPI(title="FX TAR Ingest", version="0.1.0", lifespan=lifespan)


def resolve_share_path(relative: str) -> Path:
    """Resolve a path under the share root, refusing anything that escapes it."""
    root = settings.share_root.resolve()
    path = (root / relative).resolve()
    if not path.is_relative_to(root):
        raise HTTPException(400, "tar_path must be inside the share root")
    if not path.is_file():
        raise HTTPException(404, f"TAR not found: {relative}")
    return path


@app.post("/ingest", response_model=IngestResponse)
def ingest(req: IngestRequest, db: Session = Depends(get_session)) -> IngestResponse:
    tar_path = resolve_share_path(req.tar_path)

    # Steps 1-8: TAR -> ZIPs -> JSON -> (fxId, fxDetails, createdDate)
    result = extract_records(tar_path)

    # Step 9: save to PostgreSQL. Duplicate fxIds are skipped, not errors.
    inserted = 0
    if result.records:
        stmt = (
            insert(FxRecordRow)
            .values([
                {
                    "fx_id": r.fx_id,
                    "fx_details": r.fx_details,
                    "created_date": r.created_date,
                    "source_tar": req.tar_path,
                    "source_zip": r.source_zip,
                }
                for r in result.records
            ])
            .on_conflict_do_nothing(index_elements=["fx_id"])
            .returning(FxRecordRow.id)
        )
        inserted = len(db.execute(stmt).all())
        db.commit()

    return IngestResponse(
        tar_path=req.tar_path,
        zips_processed=result.zips_seen,
        json_files_processed=result.jsons_seen,
        records_inserted=inserted,
        records_skipped_duplicate=len(result.records) - inserted,
        errors=result.errors,
    )


@app.get("/records", response_model=list[FxRecordOut])
def list_records(limit: int = 100, offset: int = 0, db: Session = Depends(get_session)):
    stmt = select(FxRecordRow).order_by(FxRecordRow.id).limit(min(limit, 1000)).offset(offset)
    return db.scalars(stmt).all()


@app.get("/records/{fx_id}", response_model=FxRecordOut)
def get_record(fx_id: str, db: Session = Depends(get_session)):
    row = db.scalar(select(FxRecordRow).where(FxRecordRow.fx_id == fx_id))
    if row is None:
        raise HTTPException(404, "Not found")
    return row
