"""Pydantic models: the JSON payload inside each ZIP, plus API request/response bodies."""
from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class FxPayload(BaseModel):
    """Shape of each JSON file inside a ZIP (see schema/fx_payload.schema.json).

    Only the three fields we persist are validated; anything else in the file
    (e.g. sourceSystem, version) is ignored.
    """
    model_config = ConfigDict(extra="ignore")

    # Reference ID arrives already hashed - assumed SHA-256 hex (64 chars).
    fxId: str = Field(pattern=r"^[0-9a-fA-F]{64}$")
    # Encrypted blob (e.g. base64 AES-GCM ciphertext). Stored as-is; we never decrypt it.
    fxDetails: str = Field(min_length=1)
    createdDate: datetime


class IngestRequest(BaseModel):
    # Path relative to FX_SHARE_ROOT, e.g. "2026/10/batch_001.tar"
    tar_path: str


class IngestResponse(BaseModel):
    tar_path: str
    zips_processed: int
    json_files_processed: int
    records_inserted: int
    records_skipped_duplicate: int
    errors: list[str]


class FxRecordOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    fx_id: str
    fx_details: str
    created_date: datetime
    source_tar: str
    source_zip: str
    ingested_at: datetime
