"""TAR -> ZIP -> JSON extraction pipeline.

Everything is streamed in memory: nothing is written to disk, which avoids
temp-file clean-up and path-traversal issues ("../../etc/passwd" member names).

Flow for one TAR:
    for each *.zip member in the TAR:
        read the ZIP bytes (size-checked)
        for each *.json member in the ZIP:
            read + parse the JSON (size-checked)
            validate it -> FxRecord
            yield it
Errors are collected per file instead of aborting the whole TAR.
"""
from __future__ import annotations

import io
import json
import logging
import tarfile
import zipfile
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Iterator

from pydantic import ValidationError

from .config import settings
from .schemas import FxPayload

log = logging.getLogger(__name__)


@dataclass
class FxRecord:
    fx_id: str
    fx_details: str
    created_date: datetime
    source_zip: str
    source_json: str


@dataclass
class ExtractionResult:
    records: list[FxRecord] = field(default_factory=list)
    zips_seen: int = 0
    jsons_seen: int = 0
    errors: list[str] = field(default_factory=list)


def iter_zip_members(tar_path: Path) -> Iterator[tuple[str, bytes]]:
    """Step 1-3: open the TAR and yield (name, bytes) for every ZIP inside it."""
    # "r:*" lets tarfile auto-detect compression (.tar, .tar.gz, .tar.bz2, ...)
    with tarfile.open(tar_path, mode="r:*") as tar:
        for member in tar:
            if not member.isfile() or not member.name.lower().endswith(".zip"):
                continue
            if member.size > settings.max_zip_bytes:
                raise ValueError(f"{member.name}: ZIP too large ({member.size} bytes)")
            fh = tar.extractfile(member)
            if fh is None:
                continue
            yield member.name, fh.read()


def iter_json_members(zip_name: str, zip_bytes: bytes) -> Iterator[tuple[str, dict]]:
    """Step 4-6: open a ZIP (from bytes) and yield (name, parsed JSON) for each .json file."""
    with zipfile.ZipFile(io.BytesIO(zip_bytes)) as zf:
        for info in zf.infolist():
            if info.is_dir() or not info.filename.lower().endswith(".json"):
                continue
            if info.file_size > settings.max_json_bytes:
                raise ValueError(f"{zip_name}/{info.filename}: JSON too large")
            with zf.open(info) as fh:
                yield info.filename, json.load(fh)


def extract_records(tar_path: Path) -> ExtractionResult:
    """Steps 1-8: walk TAR -> ZIPs -> JSONs and pull out fxId / fxDetails / createdDate."""
    result = ExtractionResult()

    for zip_name, zip_bytes in iter_zip_members(tar_path):
        result.zips_seen += 1
        try:
            for json_name, data in iter_json_members(zip_name, zip_bytes):
                result.jsons_seen += 1
                try:
                    payload = FxPayload.model_validate(data)
                except ValidationError as exc:
                    result.errors.append(f"{zip_name}/{json_name}: invalid payload: {exc.errors()}")
                    continue
                result.records.append(
                    FxRecord(
                        fx_id=payload.fxId,
                        fx_details=payload.fxDetails,
                        created_date=payload.createdDate,
                        source_zip=zip_name,
                        source_json=json_name,
                    )
                )
        except (zipfile.BadZipFile, json.JSONDecodeError, ValueError) as exc:
            log.warning("Skipping %s: %s", zip_name, exc)
            result.errors.append(f"{zip_name}: {exc}")

    return result
