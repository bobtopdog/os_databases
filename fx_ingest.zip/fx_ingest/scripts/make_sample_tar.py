"""Build a fake TAR on the "shared drive" so the pipeline can be run end to end.

    python scripts/make_sample_tar.py --zips 5 --per-zip 3

Produces sample_share/batch_001.tar containing N ZIPs, each holding M JSON files
that match schema/fx_payload.schema.json. fxId is a SHA-256 of a made-up
reference, and fxDetails is real AES-GCM ciphertext (base64) of a small JSON blob.
"""
import argparse
import base64
import hashlib
import io
import json
import os
import tarfile
import uuid
import zipfile
from datetime import datetime, timedelta, timezone
from pathlib import Path

try:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
except ImportError:  # keep the generator usable without the optional dependency
    AESGCM = None

DEMO_KEY = b"0" * 32  # demo only - real key would live in a KMS / vault


def encrypt(plaintext: bytes) -> str:
    if AESGCM is None:
        return base64.b64encode(os.urandom(12) + plaintext[::-1]).decode()  # fake
    nonce = os.urandom(12)
    return base64.b64encode(nonce + AESGCM(DEMO_KEY).encrypt(nonce, plaintext, None)).decode()


def make_payload(i: int) -> dict:
    reference = f"FX-REF-{uuid.uuid4().hex[:10].upper()}"
    details = {"pair": "GBP/USD", "amount": 1000 + i, "rate": 1.27}
    return {
        "version": "1.0",
        "sourceSystem": "FX-CORE",
        "fxId": hashlib.sha256(reference.encode()).hexdigest(),
        "fxDetails": encrypt(json.dumps(details).encode()),
        "createdDate": (datetime.now(timezone.utc) - timedelta(minutes=i)).isoformat(),
    }


def build_zip(zip_index: int, per_zip: int) -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for j in range(per_zip):
            payload = make_payload(zip_index * per_zip + j)
            zf.writestr(f"fx_{zip_index:03d}_{j:03d}.json", json.dumps(payload, indent=2))
        zf.writestr("manifest.txt", "non-JSON files are ignored by the pipeline\n")
    return buf.getvalue()


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="sample_share/batch_001.tar")
    ap.add_argument("--zips", type=int, default=5)
    ap.add_argument("--per-zip", type=int, default=3)
    args = ap.parse_args()

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    with tarfile.open(out, "w") as tar:
        for i in range(args.zips):
            data = build_zip(i, args.per_zip)
            info = tarfile.TarInfo(name=f"exports/fx_export_{i:03d}.zip")
            info.size = len(data)
            tar.addfile(info, io.BytesIO(data))
    print(f"Wrote {out} ({args.zips} zips x {args.per_zip} json)")


if __name__ == "__main__":
    main()
