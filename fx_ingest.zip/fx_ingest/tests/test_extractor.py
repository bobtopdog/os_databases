"""Pipeline tests - no database needed."""
import io
import json
import sys
import tarfile
import zipfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))

from app.extractor import extract_records  # noqa: E402
from make_sample_tar import build_zip  # noqa: E402


def write_tar(path: Path, members: dict[str, bytes]) -> Path:
    with tarfile.open(path, "w") as tar:
        for name, data in members.items():
            info = tarfile.TarInfo(name)
            info.size = len(data)
            tar.addfile(info, io.BytesIO(data))
    return path


def test_extracts_every_json_from_every_zip(tmp_path):
    tar = write_tar(tmp_path / "t.tar", {f"z{i}.zip": build_zip(i, 3) for i in range(4)})
    result = extract_records(tar)
    assert result.zips_seen == 4
    assert result.jsons_seen == 12
    assert len(result.records) == 12
    assert not result.errors
    assert all(len(r.fx_id) == 64 for r in result.records)


def test_bad_zip_and_bad_payload_are_reported_not_fatal(tmp_path):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as zf:
        zf.writestr("bad.json", json.dumps({"fxId": "not-a-hash", "fxDetails": "x",
                                            "createdDate": "2026-10-19T00:00:00Z"}))
    tar = write_tar(tmp_path / "t.tar", {
        "good.zip": build_zip(0, 2),
        "corrupt.zip": b"definitely not a zip",
        "invalid.zip": buf.getvalue(),
        "readme.txt": b"ignored",
    })
    result = extract_records(tar)
    assert len(result.records) == 2
    assert len(result.errors) == 2
    assert any("corrupt.zip" in e for e in result.errors)
    assert any("invalid payload" in e for e in result.errors)
