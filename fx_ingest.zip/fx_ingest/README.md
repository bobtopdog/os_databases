# FX TAR Ingest (prototype)

Picks up a TAR from a shared drive, walks every ZIP inside it, reads each JSON
file, pulls out `fxId` (hashed reference ID), `fxDetails` (encrypted string) and
`createdDate`, and saves them to PostgreSQL through a FastAPI endpoint.

## Process flow

```mermaid
flowchart TD
    A[Client / scheduler] -->|POST /ingest tar_path| B[FastAPI]
    B --> C{Path inside share root<br/>and file exists?}
    C -- no --> X[400 / 404]
    C -- yes --> D[Open TAR - tarfile r:*]
    D --> E{Next member}
    E -- not .zip --> E
    E -- .zip --> F[Read ZIP bytes into memory<br/>size check]
    F --> G[Open ZIP - zipfile]
    G --> H{Next member}
    H -- not .json --> H
    H -- .json --> I[Parse JSON]
    I --> J{Valid payload?<br/>fxId = 64 hex, fxDetails, createdDate}
    J -- no --> K[Record error, continue]
    J -- yes --> L[Collect fxId, fxDetails, createdDate]
    K --> H
    L --> H
    H -- done --> E
    E -- done --> M[Bulk INSERT ... ON CONFLICT fx_id DO NOTHING]
    M --> N[(PostgreSQL fx_records)]
    M --> O[Response: counts + errors]
```

Bad ZIPs and invalid JSON are logged and reported in the response; they don't
abort the rest of the TAR. Re-ingesting the same TAR is safe because `fx_id` is
unique and duplicates are skipped.

## Project layout

| File | Purpose |
|---|---|
| `app/main.py` | FastAPI app: `POST /ingest`, `GET /records`, `GET /records/{fx_id}` |
| `app/extractor.py` | TAR → ZIP → JSON pipeline (in memory, no temp files) |
| `app/schemas.py` | Pydantic models for the JSON payload and API bodies |
| `app/db.py` | SQLAlchemy engine and the `fx_records` table |
| `app/config.py` | Settings from env vars / `.env` (`FX_DATABASE_URL`, `FX_SHARE_ROOT`) |
| `schema/fx_payload.schema.json` | The made-up JSON schema for files inside each ZIP |
| `scripts/make_sample_tar.py` | Generates a sample TAR with realistic hashed IDs and AES-GCM ciphertext |
| `tests/test_extractor.py` | Pipeline tests (no DB needed) |
| `docker-compose.yml` | Local PostgreSQL 16 |

## JSON payload (inside each ZIP)

```json
{
  "version": "1.0",
  "sourceSystem": "FX-CORE",
  "fxId": "9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08",
  "fxDetails": "base64(nonce + AES-GCM ciphertext)",
  "createdDate": "2026-10-19T09:30:00+00:00"
}
```

## Table

```sql
CREATE TABLE fx_records (
    id            BIGSERIAL PRIMARY KEY,
    fx_id         VARCHAR(64) UNIQUE NOT NULL,   -- hashed reference ID
    fx_details    TEXT NOT NULL,                 -- encrypted string, stored as-is
    created_date  TIMESTAMPTZ NOT NULL,
    source_tar    TEXT NOT NULL,                 -- lineage
    source_zip    TEXT NOT NULL,
    ingested_at   TIMESTAMPTZ DEFAULT now()
);
```

The app creates this on startup (`create_all`); swap in Alembic migrations for real use.

## Running it

```bash
pip install -r requirements.txt
```

```bash
docker compose up -d
```

```bash
python scripts/make_sample_tar.py --zips 5 --per-zip 3
```

```bash
uvicorn app.main:app --reload
```

```bash
curl -X POST http://localhost:8000/ingest -H "Content-Type: application/json" -d "{\"tar_path\": \"batch_001.tar\"}"
```

Interactive docs: http://localhost:8000/docs

```bash
pytest
```

## What a production version would need

- **Share access** – mount the drive (SMB/CIFS) on the host, or use `smbprotocol`
  to read `\\server\share` directly; service-account credentials from a vault.
- **Triggering** – a scheduler or file watcher calling `/ingest`, plus a
  "processed" folder or a `processed_files` table so each TAR runs once.
- **Long jobs** – move ingestion to a background worker (Celery/RQ/ARQ) and have
  `/ingest` return a job ID; very large TARs should be inserted in batches.
- **Hashing** – confirm the upstream hash algorithm (SHA-256 assumed). If you
  need to look records up by the *original* reference, hash it the same way
  (with the same salt/pepper, if any) before querying.
- **Encryption** – `fxDetails` is stored opaque. Decide who holds the key and
  whether decryption ever happens in this service (ideally not).
- **Validation** – agree a versioned schema with the producer; route rejects
  to a dead-letter location.
- **Auth** on the API, structured logging, metrics, and Alembic migrations.
