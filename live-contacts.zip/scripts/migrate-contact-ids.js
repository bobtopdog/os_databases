#!/usr/bin/env node
/**
 * Changes every UUID-typed contact id column in the notes DB to VARCHAR(255),
 * because live contact ids look like "smithD_10".
 *
 * It FINDS the columns rather than listing them, so new tables (pocs, tags,
 * areas, highlights, community contacts…) are covered too:
 *   any column named contact_id / contactid / person_id whose type is uuid.
 *
 *   node scripts/migrate-contact-ids.js            # dry run — lists what it would change
 *   node scripts/migrate-contact-ids.js --apply    # does it, in one transaction
 *
 * Uses the same env vars as the app (DATABASE_URL, or PGHOST/PGUSER/…).
 * Safe to re-run: once a column is VARCHAR it's no longer picked up.
 * Production starts empty, so there's no data to convert; existing UUID
 * values (UAT) cast to text unchanged.
 */
const { Client } = require('pg');

const APPLY = process.argv.includes('--apply');
const NAMES = ['contact_id', 'contactid', 'person_id'];

async function main() {
  const client = new Client(
    process.env.DATABASE_URL ? { connectionString: process.env.DATABASE_URL } : undefined
  );
  await client.connect();

  try {
    const { rows } = await client.query(
      `SELECT table_schema, table_name, column_name
         FROM information_schema.columns
        WHERE data_type = 'uuid'
          AND lower(column_name) = ANY($1)
          AND table_schema NOT IN ('pg_catalog', 'information_schema')
        ORDER BY table_schema, table_name`,
      [NAMES]
    );

    if (rows.length === 0) {
      console.log('Nothing to do — no UUID contact id columns found.');
      return;
    }

    console.log(`${APPLY ? 'Changing' : 'Would change'} ${rows.length} column(s):`);
    rows.forEach((r) => console.log(`  ${r.table_schema}.${r.table_name}.${r.column_name}`));

    if (!APPLY) {
      console.log('\nDry run. Re-run with --apply to make the change.');
      return;
    }

    await client.query('BEGIN');
    for (const r of rows) {
      const tbl = `"${r.table_schema}"."${r.table_name}"`;
      const col = `"${r.column_name}"`;
      await client.query(
        `ALTER TABLE ${tbl} ALTER COLUMN ${col} TYPE VARCHAR(255) USING ${col}::text`
      );
    }
    await client.query('COMMIT');
    console.log('\nDone. Indexes and unique constraints on these columns are kept by Postgres.');
  } catch (err) {
    await client.query('ROLLBACK').catch(() => {});
    console.error('\nMigration failed — nothing was changed:', err.message);
    console.error('If a foreign key links two of these columns, drop it, re-run, and re-add it.');
    process.exitCode = 1;
  } finally {
    await client.end();
  }
}

main();
