# Switching to the live contacts service

The UI doesn't change. Everything still uses `ContactSummary` / `ContactDetail`.
The **adapter** converts the live service's field names into those types, so the
rest of the app never sees `userID`, `worktelephone`, `description` and so on.

```
Browser component ──► /api/contacts… (this app) ──► live service
  (api.ts, relative URL)    (adds Bearer token)        /api/v1/people|profiles|organisations
Server page / route ───────► liveContactsServer.ts ──► live service
```

## Files

| File | New/changed | What it does |
|---|---|---|
| `src/libs/contactsAdapter.ts` | new | Live shapes → app types. **The only file that knows the live schema.** |
| `src/libs/liveContactsServer.ts` | new | Server-only calls to the live service with the user's token. |
| `src/libs/keycloakToken.ts` | new | `getAccessToken()` reads the token from the session cookie. Also does the refresh. |
| `src/libs/authTokenCallbacks.ts` | new | `keepKeycloakTokenFresh()` to call from your NextAuth `jwt` callback. |
| `src/types/next-auth-tokens.d.ts` | new | Adds `accessToken` etc. to the JWT type. Separate file, so it merges with your existing `next-auth.d.ts`. |
| `src/app/api/contacts/route.ts` | new | Proxy: `GET /api/contacts?q=&organisation=` |
| `src/app/api/contacts/[id]/route.ts` | new | Proxy: `GET /api/contacts/:id` |
| `src/app/api/contacts/organisations/route.ts` | new | Proxy: `GET /api/contacts/organisations` → `[{id,name}]` |
| `src/libs/contactId.ts` | new | `isValidContactId()`, because ids like `smithD_10` aren't UUIDs. |
| `src/components/ContactSearchLimitNotice.tsx` | new | "Showing 20 of 134 — refine your search" banner. |
| `scripts/migrate-contact-ids.js` | new | Changes the DB's `contact_id` columns from UUID to VARCHAR. |
| `src/libs/api.ts` | changed | Only `searchContacts`, `getContact` and `getOrganisations` changed: relative URLs, and organisations are now `{id,name}`. |
| `src/types/contact.ts` | changed | Adds `Organisation`. |
| notes / anexnotes / meetings / documents / links routes (10 files) | changed | `contactId` validated with `isValidContactId`. Note, meeting, document and link ids still use UUID checks. |

## Steps

### 1. Env vars (OpenShift secret/config)
```
LIVE_CONTACTS_API_URL=https://<url>/api/v1
```
`KEYCLOAK_ISSUER`, `KEYCLOAK_CLIENT_ID` and `KEYCLOAK_CLIENT_SECRET` are already set. The refresh uses them.
If the live service uses the corporate CA, `NODE_EXTRA_CA_CERTS` already covers it.
You can delete `NEXT_PUBLIC_API_BASE_URL` once nothing else uses it.

### 2. NextAuth: store the token (this is the bearer-token part)
In your `authOptions`:
```ts
import { keepKeycloakTokenFresh } from '@/libs/authTokenCallbacks';

callbacks: {
  async jwt({ token, account, profile }) {
    // …your existing roles/username code…
    return keepKeycloakTokenFresh(token, account);   // ← last line
  },
  async session({ session, token }) {
    // …existing…
    session.error = token.error;     // flag only
    return session;
  },
},
```
**Don't** put `token.accessToken` on the session. The browser can read the session at
`/api/auth/session`. The token is kept in the encrypted, httpOnly cookie and is
read server-side by `getAccessToken()`.

If you already copy `accessToken` into the session, remove that line. If you call the
live API from a client component with that token, switch to the proxy routes.

Optional: `<SessionProvider refetchInterval={4 * 60}>`. This keeps the cookie's token fresh
while a page is left open. Keycloak access tokens last about 5 minutes.

Optional: sign the user out when a refresh fails:
```ts
const { data: session } = useSession();
useEffect(() => { if (session?.error === 'RefreshAccessTokenError') signIn('keycloak'); }, [session]);
```

### 3. Run the migration (both UAT and prod)
```
node scripts/migrate-contact-ids.js           # dry run: check the list
node scripts/migrate-contact-ids.js --apply
```

### 4. Organisation dropdown
`getOrganisations()` now returns `{ id, name }[]`:
```tsx
{orgs.map(o => <option key={o.id} value={o.id}>{o.name}</option>)}
```
Pass the **id** to `searchContacts(query, orgId)`. Change the TanStack key's
type if it was typed as `string[]`.

### 5. Search results notice
```tsx
<ContactSearchLimitNotice result={data} />
```
Put it above the results list. Remove any pager, because there's only ever one page.

### 6. Server code: switch the imports
`searchContacts`, `getContact` and `getOrganisations` now **throw if called on the
server**. That's deliberate: on the server, a relative URL has no host, and there's no
cookie to forward. Find the server call sites:
```
grep -rn "searchContacts\|getContact(\|getOrganisations" src/app --include=page.tsx --include=route.ts
```
Likely places: the contact detail page, My Contacts, the `/api/network` route, and the community
contacts page. Change each to:
```ts
import { getLiveProfile, searchLivePeople, getLiveOrganisations } from '@/libs/liveContactsServer';
const contact = await getLiveProfile(id);          // null if not found → notFound()
```

### 7. Other routes that check `contactId`
The routes I had are done. Others that weren't in the upload (POCs, tags, areas,
headlines, highlight notes, community contacts, network) need the same one-line swap:
```
grep -rn "isValidUuid(contactId\|UUID.test(contactId" src/app
```
→ `import { isValidContactId } from '@/libs/contactId';` and `isValidContactId(contactId)`.

## Things to know
- **Demo bypass / GitHub login has no Keycloak token.** Live calls return 401 there, so
  test against Keycloak.
- **Name join:** sample data has `firstname: "David Jones"` with `surname: "Jones"`, so
  `joinName()` skips the surname if firstname already ends with it.
- **`userID` vs `userId`:** `/people` uses a capital D and `/profiles` doesn't. The adapter accepts both.
- **`people: null`** for no matches is handled (it becomes an empty list).
- **`createdAt`** is `''` because the live service doesn't supply it. Hide it if the detail page shows it.
- **Keycloak "Revoke Refresh Token"**: if that realm setting is on and two tabs refresh at
  once, one can get logged out. If users report random logouts, check that setting.
- Errors: the live service's 401/403 → proxy 401; 404 → 404; anything else → 502 (logged server-side).
